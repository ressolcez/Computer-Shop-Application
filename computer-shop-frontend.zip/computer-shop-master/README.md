Część Front-End sklepu internetowego, zrealizowana w technologii React-JS.

