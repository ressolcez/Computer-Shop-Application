import React from 'react'
import RegisterComponent from '../AuthComponents/RegisterComponent'

function Register() {
  return (
    <>
    <RegisterComponent/>
    </>
  )
}

export default Register