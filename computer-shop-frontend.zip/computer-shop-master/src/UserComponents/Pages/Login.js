import React from 'react'
import LoginComponent from '../AuthComponents/LoginComponent'


function Login() {
  return (
    <>
      <LoginComponent/>
    </>
  )
}

export default Login