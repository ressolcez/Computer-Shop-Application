Część Back-End sklepu internetowego, zrealizowana w technologii Spring-boot.
